<div class="page_single layout_fullwidth_padding">
    <div class="success_message">
        <span>Terima Kasih!</span>
        <img src="images/icons/black/rocket.png" alt="" title="" />
        <p>Pendaftaran Anda <br />Berhasil.</p>
        <a href="<?= base_url('login') ?>" class="open-popup">Klik Untuk Login</a>
    </div>
</div>
