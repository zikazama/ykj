<div class="panel panel-left panel-reveal">
	<!-- Slider -->
	<div class="swiper-container-subnav multinav">
		<div class="swiper-wrapper">
			<div class="swiper-slide">
				<nav class="main_nav_underline">
					<ul>
						<li><a href="index.html"><img src="<?= base_url() ?>assets/images/icons/gray/home.png" alt="" title="" /><span>Home</span></a></li>
						<li><a href="about.html"><img src="<?= base_url() ?>assets/images/icons/gray/mobile.png" alt="" title="" /><span>About</span></a></li>

					</ul>
				</nav>
			</div>
		
		</div>
	</div>
</div>