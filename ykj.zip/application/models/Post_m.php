<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_m extends Base_m {

    public $table = 'post';

}
