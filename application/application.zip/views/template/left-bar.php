<div class="panel panel-left panel-reveal">
	<!-- Slider -->
	<div class="swiper-container-subnav multinav">
		<div class="swiper-wrapper">
			<div class="swiper-slide">
				<nav class="main_nav_underline">
					<ul>
						<li><a href="<?= base_url() ?>"><img src="<?= base_url() ?>assets/images/icons/gray/home.png" alt="" title="" /><span>Home</span></a></li>
						<li><a href="<?= base_url('page/tentang') ?>"><img src="<?= base_url() ?>assets/images/icons/gray/mobile.png" alt="" title="" /><span>Tentang</span></a></li>
						<li><a href="<?= base_url('page/dukung') ?>"><img src="<?= base_url() ?>assets/images/icons/gray/mobile.png" alt="" title="" /><span>Dukung UMKM</span></a></li>
						<li><a href="<?= base_url('page/bantuan') ?>"><img src="<?= base_url() ?>assets/images/icons/gray/mobile.png" alt="" title="" /><span>Bantuan</span></a></li>
						<li><a href="<?= base_url('jajan/direct') ?>"><img src="<?= base_url() ?>assets/images/icons/gray/tables.png" alt="" title="" /><span>Lihat Jajanan Sekitar</span></a></li>
						<li><a href="<?= base_url('jajan/posting') ?>"><img src="<?= base_url() ?>assets/images/icons/gray/features.png" alt="" title="" /><span>Posting Jajanan</span></a></li>
						<li><a href="<?= base_url('ranking') ?>"><img src="<?= base_url() ?>assets/images/icons/gray/categories.png" alt="" title="" /><span>Peringkat Jajaners</span></a></li>
					</ul>
				</nav>
			</div>
		
		</div>
	</div>
</div>