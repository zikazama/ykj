<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Favorit_m extends Base_m {

    public $table = 'favorit';

}
