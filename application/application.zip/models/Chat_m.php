<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chat_m extends Base_m {

    public $table = 'chat';

}
